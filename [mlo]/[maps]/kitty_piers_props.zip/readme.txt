Kitty Piers REDM|PROPS

This package features 8 custom made piers. 

Prop names:
k_p_pier_01
k_p_pier_02
k_p_pier_03
k_p_pier_04
k_p_pier_05
k_p_pier_06
k_p_pier_07
k_p_pier_08

Installation: 1. Unzip the file and drag into your resources.
	      2. Ensure the resource.

Each of the props can be placed with Spooner.
1. Open Spooner
2. Go to Objects
3. Type the correct name of the prop
4. Go to "Spawn by name"
5. Press "E" on your keyboard